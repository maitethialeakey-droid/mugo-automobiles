import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { trpc } from "@/lib/trpc";
import { startLogin } from "@/const";
import { AlertTriangle, ArrowUpRight, BarChart3, CarFront, CheckCircle2, ClipboardList, FileUp, ImagePlus, Loader2, Plus, RefreshCw, Upload, Users } from "lucide-react";
import { useEffect, useMemo, useState, type ChangeEvent } from "react";
import { useLocation } from "wouter";

const blankVehicle = {
  stockNumber: "",
  vin: "",
  make: "",
  model: "",
  trim: "",
  year: new Date().getFullYear(),
  bodyType: "SUV",
  fuelType: "Petrol",
  transmission: "Automatic",
  mileageKm: 0,
  exteriorColor: "",
  location: "Nairobi, Kenya",
  priceKsh: 0,
  fobPriceKsh: 0,
  shippingCostKsh: 0,
  dutyCostKsh: 0,
  marginKsh: 0,
  description: "",
  conditionSummary: "",
};

const formatKsh = (value: number) => new Intl.NumberFormat("en-KE", { style: "currency", currency: "KES", maximumFractionDigits: 0 }).format(value);
const formatDate = (value: Date | string | null) => value ? new Intl.DateTimeFormat("en-KE", { dateStyle: "medium" }).format(new Date(value)) : "—";

async function fileToDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

async function compressImage(file: File) {
  if (!file.type.startsWith("image/")) return fileToDataUrl(file);
  const image = await new Promise<HTMLImageElement>((resolve, reject) => {
    const objectUrl = URL.createObjectURL(file);
    const element = new Image();
    element.onload = () => { URL.revokeObjectURL(objectUrl); resolve(element); };
    element.onerror = reject;
    element.src = objectUrl;
  });
  const maxWidth = 1800;
  const scale = Math.min(1, maxWidth / image.width);
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(image.width * scale);
  canvas.height = Math.round(image.height * scale);
  const context = canvas.getContext("2d");
  if (!context) return fileToDataUrl(file);
  context.drawImage(image, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/jpeg", 0.84);
}

function Metric({ label, value, note, icon: Icon }: { label: string; value: string | number; note: string; icon: typeof CarFront }) {
  return <article className="rounded-2xl border border-[#e9e3d6] bg-white p-5 shadow-[0_12px_32px_rgba(15,31,75,.06)]"><div className="flex items-start justify-between gap-4"><div><p className="text-[10px] font-bold uppercase tracking-[.14em] text-[#a47b06]">{label}</p><strong className="mt-2 block text-3xl font-bold tracking-[-.06em] text-[#0f1f4b]">{value}</strong><span className="mt-2 block text-xs text-[#777269]">{note}</span></div><span className="grid h-10 w-10 place-items-center rounded-xl bg-[#0f1f4b] text-[#efc94c]"><Icon size={19} /></span></div></article>;
}

export default function AdminDashboard() {
  const { user, loading } = useAuth();
  const [location, setLocation] = useLocation();
  const [formOpen, setFormOpen] = useState(false);
  const [vehicleForm, setVehicleForm] = useState(blankVehicle);
  const [mediaFiles, setMediaFiles] = useState<File[]>([]);
  const [bulkFile, setBulkFile] = useState<File | null>(null);
  const isAdmin = Boolean(user && user.role !== "user");
  const isOwner = user?.role === "admin";
  const section = location.split("/")[2] || "overview";
  const allowedSections = user?.role === "admin"
    ? ["overview", "inventory", "orders", "customers", "analytics", "staff"]
    : user?.role === "inventory_manager"
      ? ["overview", "inventory"]
      : user?.role === "sales_manager"
        ? ["overview", "orders", "customers", "analytics"]
        : user?.role === "support_agent"
          ? ["overview", "customers"]
          : [];
  const utils = trpc.useUtils();
  const summary = trpc.marketplace.admin.summary.useQuery(undefined, { enabled: isAdmin });
  const vehicleList = trpc.marketplace.vehicles.adminList.useQuery(undefined, { enabled: isAdmin });
  const orderList = trpc.marketplace.orders.adminList.useQuery(undefined, { enabled: isAdmin });
  const inquiryList = trpc.marketplace.inquiries.adminList.useQuery(undefined, { enabled: isAdmin });
  const staffList = trpc.marketplace.staff.list.useQuery(undefined, { enabled: isOwner });
  const createVehicle = trpc.marketplace.vehicles.create.useMutation({ onSuccess: () => utils.marketplace.vehicles.adminList.invalidate() });
  const updateStatus = trpc.marketplace.vehicles.updateStatus.useMutation({ onSuccess: () => { utils.marketplace.vehicles.adminList.invalidate(); utils.marketplace.admin.summary.invalidate(); } });
  const cloneVehicle = trpc.marketplace.vehicles.clone.useMutation({ onSuccess: () => utils.marketplace.vehicles.adminList.invalidate() });
  const upload = trpc.marketplace.uploads.upload.useMutation();
  const createOrder = trpc.marketplace.orders.create.useMutation({ onSuccess: () => { utils.marketplace.orders.adminList.invalidate(); utils.marketplace.inquiries.adminList.invalidate(); utils.marketplace.vehicles.adminList.invalidate(); } });
  const updateOrderStatus = trpc.marketplace.orders.updateStatus.useMutation({ onSuccess: () => utils.marketplace.orders.adminList.invalidate() });
  const reconcilePayment = trpc.marketplace.orders.reconcilePayment.useMutation({ onSuccess: () => utils.marketplace.orders.adminList.invalidate() });
  const generateOrderDocument = trpc.marketplace.orders.generateDocument.useMutation({ onSuccess: () => tell("Document generated and stored in the buyer document center.") });
  const updateStaffRole = trpc.marketplace.staff.updateRole.useMutation({ onSuccess: () => utils.marketplace.staff.list.invalidate() });
  const [notice, setNotice] = useState<string | null>(null);

  const publishedCount = useMemo(() => Number(summary.data?.inventoryCounts.find((item) => item.status === "published")?.count ?? 0), [summary.data]);
  const draftCount = useMemo(() => Number(summary.data?.inventoryCounts.find((item) => item.status === "draft")?.count ?? 0), [summary.data]);

  const tell = (message: string) => {
    setNotice(message);
    window.setTimeout(() => setNotice(null), 3200);
  };

  const updateForm = (field: keyof typeof vehicleForm, value: string | number) => setVehicleForm((current) => ({ ...current, [field]: value }));

  const submitVehicle = async () => {
    try {
      const result = await createVehicle.mutateAsync({ ...vehicleForm, vin: vehicleForm.vin || null, trim: vehicleForm.trim || null, exteriorColor: vehicleForm.exteriorColor || null, description: vehicleForm.description || null, conditionSummary: vehicleForm.conditionSummary || null, status: "draft" });
      for (const file of mediaFiles) {
        await upload.mutateAsync({ dataUrl: await compressImage(file), fileName: file.name.replace(/\.[^.]+$/, ".jpg"), purpose: "vehicle_media", vehicleId: result.id });
      }
      setVehicleForm(blankVehicle);
      setMediaFiles([]);
      setFormOpen(false);
      await utils.marketplace.vehicles.adminList.invalidate();
      tell("Draft created. Add the final VIN and publish when it is ready.");
    } catch (error) {
      tell(error instanceof Error ? error.message : "Could not create the vehicle draft.");
    }
  };

  const submitBulkFile = async () => {
    if (!bulkFile) return;
    try {
      const result = await upload.mutateAsync({ dataUrl: await fileToDataUrl(bulkFile), fileName: bulkFile.name, purpose: "bulk_import" });
      setBulkFile(null);
      await utils.marketplace.vehicles.adminList.invalidate();
      const importResult = result as typeof result & { rowsImported?: number; rowsReceived?: number };
      tell(`${importResult.rowsImported ?? 0} of ${importResult.rowsReceived ?? 0} spreadsheet rows were staged as drafts.`);
    } catch (error) {
      tell(error instanceof Error ? error.message : "Could not upload the import file.");
    }
  };

  const clone = async (vehicleId: number, stockNumber: string) => {
    const nextStock = window.prompt("New stock number", `${stockNumber}-COPY`);
    if (!nextStock) return;
    try { await cloneVehicle.mutateAsync({ vehicleId, stockNumber: nextStock }); tell("Listing cloned as a draft. Add a VIN, photos, and final price before publishing."); } catch (error) { tell(error instanceof Error ? error.message : "Could not clone listing."); }
  };

  const reserveFromInquiry = async (vehicleId: number, buyerId: number, inquiryId: number, priceKsh: number) => {
    try {
      await createOrder.mutateAsync({ vehicleId, buyerId, inquiryId, agreedPriceKsh: priceKsh });
      tell("Vehicle reserved and the order pipeline has been opened.");
    } catch (error) {
      tell(error instanceof Error ? error.message : "Could not create the reservation.");
    }
  };

  const nextOrderStatus = (status: string) => ({ inquiry: "reserved", reserved: "paid", paid: "shipping", shipping: "delivered", delivered: "closed", closed: "closed", cancelled: "cancelled", refunded: "refunded" }[status] as "inquiry" | "reserved" | "paid" | "shipping" | "delivered" | "closed" | "cancelled" | "refunded");

  useEffect(() => {
    if (isAdmin && !allowedSections.includes(section)) setLocation("/admin");
  }, [allowedSections, isAdmin, section, setLocation]);

  if (loading) return <div className="grid min-h-screen place-items-center bg-[#f6f4ee]"><Loader2 className="animate-spin text-[#0f1f4b]" /></div>;
  if (!user) return <div className="grid min-h-screen place-items-center bg-[#f6f4ee] p-6"><div className="max-w-md rounded-3xl bg-white p-8 text-center shadow-xl"><CarFront className="mx-auto text-[#a47b06]" /><h1 className="mt-4 text-3xl font-bold text-[#0f1f4b]">Operations are secured.</h1><p className="mt-3 text-sm leading-6 text-[#777269]">Sign in to access your Mugo marketplace workspace.</p><button className="mt-6 rounded-xl bg-[#0f1f4b] px-5 py-3 text-sm font-bold text-white" onClick={() => startLogin()}>Sign in to continue</button></div></div>;

  return <DashboardLayout><div className="min-h-full bg-[#f6f4ee] p-2 sm:p-5"><div className="mx-auto max-w-7xl">{!isAdmin ? <div className="rounded-3xl border border-[#efc94c] bg-white p-10"><p className="text-xs font-bold uppercase tracking-[.14em] text-[#a47b06]">Access restricted</p><h1 className="mt-3 text-4xl font-bold tracking-[-.06em] text-[#0f1f4b]">Seller operations are reserved for administrators.</h1><p className="mt-4 max-w-2xl text-sm leading-7 text-[#777269]">Your buyer account can still use saved vehicles, orders, messages, and documents once the buyer dashboard is connected.</p><a href="/" className="mt-7 inline-flex items-center gap-2 rounded-xl bg-[#0f1f4b] px-5 py-3 text-sm font-bold text-white">Return to showroom <ArrowUpRight size={16} /></a></div> : <>
    <header className="mb-7 flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><p className="text-[10px] font-bold uppercase tracking-[.14em] text-[#a47b06]">Mugo seller workspace</p><h1 className="mt-2 text-4xl font-bold tracking-[-.07em] text-[#0f1f4b]">{section === "overview" ? "A clear view of the route." : section[0].toUpperCase() + section.slice(1)}</h1><p className="mt-2 text-sm text-[#777269]">Inventory, customer movement, and money rails in one considered workspace.</p></div><div className="flex items-center gap-3"><a href="/" className="rounded-xl border border-[#dad5ca] bg-white px-4 py-2.5 text-xs font-bold text-[#0f1f4b]">View showroom</a>{section === "inventory" && <button className="inline-flex items-center gap-2 rounded-xl bg-[#efc94c] px-4 py-2.5 text-xs font-bold text-[#0f1f4b]" onClick={() => setFormOpen(true)}><Plus size={16} /> Add vehicle</button>}</div></header>

    {section === "staff" && <section className="overflow-hidden rounded-3xl border border-[#e9e3d6] bg-white"><div className="border-b border-[#eee9df] p-5"><p className="text-[10px] font-bold uppercase tracking-[.14em] text-[#a47b06]">Team access</p><h2 className="mt-1 text-xl font-bold tracking-[-.05em] text-[#0f1f4b]">Assign the right route to each staff member.</h2><p className="mt-2 text-sm text-[#777269]">Inventory managers control listings and media. Sales managers manage orders and documents. Support agents work buyer inquiries. Administrators retain full access.</p></div>{!isOwner ? <div className="p-10 text-center text-sm text-[#777269]">Only an administrator can assign staff roles.</div> : <div className="divide-y divide-[#eee9df]">{staffList.data?.map((member) => <div className="grid gap-3 p-5 md:grid-cols-[1fr_200px_auto] md:items-center" key={member.id}><div><strong className="text-sm text-[#0f1f4b]">{member.name || "Unnamed account"}</strong><span className="mt-1 block text-xs text-[#777269]">{member.email || member.openId || `User #${member.id}`} · Last seen {formatDate(member.lastSignedIn)}</span></div><select aria-label={`Role for ${member.name || member.id}`} className="rounded-xl border border-[#d8d0c2] bg-white px-3 py-2.5 text-sm font-bold text-[#0f1f4b]" value={member.role} disabled={member.id === user.id || updateStaffRole.isPending} onChange={(event) => updateStaffRole.mutate({ userId: member.id, role: event.currentTarget.value as "user" | "admin" | "inventory_manager" | "sales_manager" | "support_agent" })}><option value="user">Buyer</option><option value="inventory_manager">Inventory manager</option><option value="sales_manager">Sales manager</option><option value="support_agent">Support agent</option><option value="admin">Administrator</option></select><span className="text-xs text-[#777269]">{member.id === user.id ? "Your administrator role" : "Role updates apply on the next request."}</span></div>)}{!staffList.data?.length && <div className="p-10 text-center text-sm text-[#777269]">Team members appear here after they sign in for the first time.</div>}</div>}</section>}

    {section === "overview" && <><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4"><Metric label="Published inventory" value={publishedCount} note={`${draftCount} staged as draft`} icon={CarFront} /><Metric label="Open conversations" value={summary.data?.openInquiryCount ?? "—"} note="New and in-progress inquiries" icon={Users} /><Metric label="Aging inventory" value={summary.data?.agingInventory.length ?? "—"} note="Published more than 60 days" icon={AlertTriangle} /><Metric label="Reconciled revenue" value={formatKsh(summary.data?.reconciledRevenueKsh ?? 0)} note="Across connected payment records" icon={BarChart3} /></div><div className="mt-6 grid gap-6 xl:grid-cols-[1.25fr_.75fr]"><section className="rounded-3xl bg-[#0f1f4b] p-6 text-white"><div className="flex items-center justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[.14em] text-[#efc94c]">Next operations</p><h2 className="mt-2 text-2xl font-bold tracking-[-.06em]">Move each car with intention.</h2></div><ClipboardList className="text-[#efc94c]" /></div><div className="mt-6 grid gap-3 sm:grid-cols-3"><button onClick={() => setLocation("/admin/inventory")} className="rounded-2xl bg-white/10 p-4 text-left transition hover:bg-white/15"><span className="text-xs text-white/60">01</span><strong className="mt-2 block text-sm">Stage listings</strong><span className="mt-1 block text-xs text-white/60">Draft, clone, upload, publish.</span></button><button onClick={() => setLocation("/admin/orders")} className="rounded-2xl bg-white/10 p-4 text-left transition hover:bg-white/15"><span className="text-xs text-white/60">02</span><strong className="mt-2 block text-sm">Work the pipeline</strong><span className="mt-1 block text-xs text-white/60">Inquiry to delivery and close.</span></button><button onClick={() => setLocation("/admin/customers")} className="rounded-2xl bg-white/10 p-4 text-left transition hover:bg-white/15"><span className="text-xs text-white/60">03</span><strong className="mt-2 block text-sm">Keep every follow-up visible</strong><span className="mt-1 block text-xs text-white/60">Turn inquiry history into care.</span></button></div></section><section className="rounded-3xl border border-[#e9e3d6] bg-white p-6"><div className="flex items-center justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[.14em] text-[#a47b06]">Aging inventory watch</p><h2 className="mt-2 text-xl font-bold tracking-[-.05em] text-[#0f1f4b]">Review before it lingers.</h2></div><AlertTriangle className="text-[#a47b06]" /></div><div className="mt-5 space-y-3">{summary.data?.agingInventory.length ? summary.data.agingInventory.slice(0, 3).map((vehicle) => <div className="flex items-center justify-between border-t border-[#eee9df] pt-3" key={vehicle.id}><div><strong className="text-sm text-[#0f1f4b]">{vehicle.make} {vehicle.model}</strong><span className="mt-1 block text-xs text-[#777269]">Listed {formatDate(vehicle.listedAt)}</span></div><button className="text-xs font-bold text-[#a47b06]" onClick={() => setLocation("/admin/inventory")}>Review</button></div>) : <p className="py-8 text-sm text-[#777269]">No published vehicles have crossed the 60-day watch threshold.</p>}</div></section></div></>}

    {section === "inventory" && <section className="space-y-5"><div className="grid gap-4 rounded-3xl border border-dashed border-[#d8d0c2] bg-white p-5 lg:grid-cols-[1fr_auto]"><div><p className="text-[10px] font-bold uppercase tracking-[.14em] text-[#a47b06]">Bulk intake</p><h2 className="mt-1 text-xl font-bold tracking-[-.05em] text-[#0f1f4b]">Upload a CSV or Excel arrival list.</h2><p className="mt-2 text-sm text-[#777269]">Files are stored securely and placed in the import-validation queue. Use individual listing drafts when you need a richer spec sheet.</p></div><div className="flex flex-col gap-2 sm:flex-row sm:items-center"><input className="max-w-[230px] text-xs" type="file" accept=".csv,.xlsx,.xls" onChange={(event: ChangeEvent<HTMLInputElement>) => setBulkFile(event.currentTarget.files?.[0] ?? null)} /><button disabled={!bulkFile || upload.isPending} onClick={submitBulkFile} className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#0f1f4b] px-4 py-3 text-xs font-bold text-white disabled:opacity-40"><FileUp size={16} /> Store import</button></div></div><div className="overflow-hidden rounded-3xl border border-[#e9e3d6] bg-white"><div className="flex items-center justify-between border-b border-[#eee9df] p-5"><div><p className="text-[10px] font-bold uppercase tracking-[.14em] text-[#a47b06]">Listing control</p><h2 className="mt-1 text-xl font-bold tracking-[-.05em] text-[#0f1f4b]">Inventory lifecycle</h2></div><button className="inline-flex items-center gap-2 rounded-xl border border-[#d8d0c2] px-3 py-2 text-xs font-bold text-[#0f1f4b]" onClick={() => vehicleList.refetch()}><RefreshCw size={14} /> Refresh</button></div><div className="overflow-x-auto"><table className="min-w-[820px] w-full text-left"><thead className="bg-[#fbfaf7] text-[10px] font-bold uppercase tracking-[.12em] text-[#777269]"><tr><th className="px-5 py-3">Vehicle</th><th className="px-4 py-3">Stock / VIN</th><th className="px-4 py-3">Price</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Media</th><th className="px-5 py-3 text-right">Actions</th></tr></thead><tbody>{vehicleList.data?.map((vehicle) => <tr className="border-t border-[#eee9df] text-sm" key={vehicle.id}><td className="px-5 py-4"><div className="flex items-center gap-3">{vehicle.media[0]?.url ? <img className="h-10 w-14 rounded-lg object-cover" src={vehicle.media[0].url} alt="" /> : <div className="grid h-10 w-14 place-items-center rounded-lg bg-[#f3efe6] text-[#a47b06]"><CarFront size={17} /></div>}<div><strong className="text-[#0f1f4b]">{vehicle.year} {vehicle.make} {vehicle.model}</strong><span className="mt-1 block text-xs text-[#777269]">{vehicle.location ?? "Location pending"}</span></div></div></td><td className="px-4 py-4 text-xs text-[#777269]"><strong className="block text-[#0f1f4b]">{vehicle.stockNumber}</strong>{vehicle.vin || "VIN pending"}</td><td className="px-4 py-4 font-bold text-[#0f1f4b]">{formatKsh(vehicle.priceKsh)}</td><td className="px-4 py-4"><span className={`rounded-full px-2.5 py-1 text-[10px] font-bold ${vehicle.status === "published" ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"}`}>{vehicle.status}</span></td><td className="px-4 py-4 text-xs text-[#777269]">{vehicle.media.length} file{vehicle.media.length === 1 ? "" : "s"}</td><td className="px-5 py-4"><div className="flex justify-end gap-2"><button className="rounded-lg border border-[#d8d0c2] px-2.5 py-1.5 text-xs font-bold text-[#0f1f4b]" onClick={() => clone(vehicle.id, vehicle.stockNumber)}>Clone</button><button className="rounded-lg bg-[#0f1f4b] px-2.5 py-1.5 text-xs font-bold text-white" onClick={() => updateStatus.mutate({ vehicleId: vehicle.id, status: vehicle.status === "published" ? "draft" : "published" })}>{vehicle.status === "published" ? "Unpublish" : "Publish"}</button></div></td></tr>)}</tbody></table>{!vehicleList.data?.length && <div className="p-10 text-center"><CarFront className="mx-auto text-[#a47b06]" /><h3 className="mt-3 font-bold text-[#0f1f4b]">No listings yet.</h3><p className="mt-1 text-sm text-[#777269]">Create a draft or store an import file to begin the arrival list.</p></div>}</div></div></section>}

    {section === "orders" && <section className="overflow-hidden rounded-3xl border border-[#e9e3d6] bg-white"><div className="border-b border-[#eee9df] p-5"><p className="text-[10px] font-bold uppercase tracking-[.14em] text-[#a47b06]">Sales & orders</p><h2 className="mt-1 text-xl font-bold tracking-[-.05em] text-[#0f1f4b]">From inquiry to closed.</h2><p className="mt-2 text-sm text-[#777269]">Payment reconciliation remains neutral until a merchant rail is connected; invoices, receipts, cancellations, refunds, and delivery stages are already tracked per order.</p></div><div className="grid gap-px bg-[#eee9df] md:grid-cols-4">{["inquiry", "reserved", "paid", "shipping", "delivered", "closed"].map((status) => <div className="bg-white p-4" key={status}><span className="text-[10px] font-bold uppercase tracking-[.12em] text-[#777269]">{status}</span><strong className="mt-2 block text-2xl tracking-[-.06em] text-[#0f1f4b]">{orderList.data?.filter((row) => row.order.status === status).length ?? 0}</strong></div>)}</div><div className="p-5"><h3 className="text-sm font-bold text-[#0f1f4b]">Order ledger</h3><div className="mt-3 space-y-3">{orderList.data?.length ? orderList.data.map((row) => <div className="rounded-2xl border border-[#eee9df] p-4" key={row.order.id}><div className="flex flex-wrap items-center justify-between gap-3"><div><strong className="text-sm text-[#0f1f4b]">{row.vehicle.make} {row.vehicle.model}</strong><span className="ml-2 text-xs text-[#777269]">Order #{row.order.id}</span></div><span className="rounded-full bg-[#f3efe6] px-2.5 py-1 text-[10px] font-bold uppercase tracking-[.08em] text-[#a47b06]">{row.order.status}</span><strong className="text-sm text-[#0f1f4b]">{formatKsh(row.order.agreedPriceKsh)}</strong></div><div className="mt-4 flex flex-wrap gap-2 border-t border-[#eee9df] pt-3"><button disabled={row.order.status === "closed" || row.order.status === "cancelled" || row.order.status === "refunded"} onClick={() => updateOrderStatus.mutate({ orderId: row.order.id, status: nextOrderStatus(row.order.status) })} className="rounded-lg bg-[#0f1f4b] px-3 py-2 text-xs font-bold text-white disabled:opacity-40">Advance stage</button><button onClick={() => generateOrderDocument.mutate({ orderId: row.order.id, kind: "invoice" })} className="rounded-lg border border-[#d8d0c2] px-3 py-2 text-xs font-bold text-[#0f1f4b]">Invoice PDF</button><button onClick={() => generateOrderDocument.mutate({ orderId: row.order.id, kind: "receipt" })} className="rounded-lg border border-[#d8d0c2] px-3 py-2 text-xs font-bold text-[#0f1f4b]">Receipt PDF</button>{row.payment && <button onClick={() => reconcilePayment.mutate({ paymentId: row.payment.id, status: "reconciled" })} className="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs font-bold text-emerald-700">Reconcile payment</button>}<button onClick={() => { const reason = window.prompt("Cancellation reason"); if (reason) updateOrderStatus.mutate({ orderId: row.order.id, status: "cancelled", cancellationReason: reason }); }} className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-bold text-amber-700">Cancel</button><button onClick={() => { const reason = window.prompt("Refund reason"); if (reason) updateOrderStatus.mutate({ orderId: row.order.id, status: "refunded", cancellationReason: reason }); }} className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-bold text-rose-700">Refund</button></div></div>) : <p className="py-10 text-center text-sm text-[#777269]">Orders will appear here as reservations and payments are created.</p>}</div></div></section>}

    {section === "customers" && <section className="overflow-hidden rounded-3xl border border-[#e9e3d6] bg-white"><div className="border-b border-[#eee9df] p-5"><p className="text-[10px] font-bold uppercase tracking-[.14em] text-[#a47b06]">CRM-lite</p><h2 className="mt-1 text-xl font-bold tracking-[-.05em] text-[#0f1f4b]">Every question has a history.</h2></div><div className="divide-y divide-[#eee9df]">{inquiryList.data?.length ? inquiryList.data.map((row) => <article className="grid gap-3 p-5 md:grid-cols-[1fr_auto_auto]"><div><div className="flex items-center gap-2"><strong className="text-sm text-[#0f1f4b]">{row.inquiry.contactName}</strong><span className="rounded-full bg-[#f3efe6] px-2 py-0.5 text-[9px] font-bold uppercase text-[#a47b06]">{row.inquiry.status}</span></div><p className="mt-2 max-w-xl text-sm leading-6 text-[#777269]">{row.inquiry.message}</p></div><div className="text-xs text-[#777269]"><strong className="block text-[#0f1f4b]">{row.vehicle ? `${row.vehicle.make} ${row.vehicle.model}` : "General enquiry"}</strong>{row.inquiry.contactEmail || row.inquiry.contactPhone || "Contact details pending"}</div><button className="rounded-xl border border-[#d8d0c2] px-3 py-2 text-xs font-bold text-[#0f1f4b]" onClick={() => tell("Conversation threads will be opened from this customer row in the next stage.")}>Open thread</button></article>) : <div className="p-10 text-center"><Users className="mx-auto text-[#a47b06]" /><p className="mt-3 text-sm text-[#777269]">New buyer messages will appear here with their linked vehicle and follow-up status.</p></div>}</div></section>}

    {section === "analytics" && <section className="grid gap-6 xl:grid-cols-[1fr_.8fr]"><div className="rounded-3xl bg-[#0f1f4b] p-6 text-white"><p className="text-[10px] font-bold uppercase tracking-[.14em] text-[#efc94c]">Marketplace signals</p><h2 className="mt-2 text-3xl font-bold tracking-[-.06em]">Build the picture from real movement.</h2><p className="mt-3 max-w-xl text-sm leading-6 text-white/65">This foundation aggregates listing availability, inquiry stages, aging inventory, and reconciled payments. Detailed traffic-source and conversion reporting will become meaningful as real views, inquiries, and orders arrive.</p><div className="mt-7 grid gap-3 sm:grid-cols-2"><div className="rounded-2xl bg-white/10 p-4"><span className="text-xs text-white/60">Published</span><strong className="mt-2 block text-3xl">{publishedCount}</strong></div><div className="rounded-2xl bg-white/10 p-4"><span className="text-xs text-white/60">Open inquiries</span><strong className="mt-2 block text-3xl">{summary.data?.openInquiryCount ?? 0}</strong></div></div></div><div className="rounded-3xl border border-[#e9e3d6] bg-white p-6"><p className="text-[10px] font-bold uppercase tracking-[.14em] text-[#a47b06]">Payment readiness</p><h2 className="mt-2 text-xl font-bold tracking-[-.05em] text-[#0f1f4b]">Reconciliation table ready.</h2><p className="mt-3 text-sm leading-6 text-[#777269]">Provider records can be linked to each order and marked pending, reconciled, failed, or refunded. Activate M-Pesa, Pesapal/Flutterwave, PayPal, or crypto once merchant credentials and webhook requirements are confirmed.</p><button className="mt-6 inline-flex items-center gap-2 rounded-xl border border-[#d8d0c2] px-4 py-2.5 text-xs font-bold text-[#0f1f4b]" onClick={() => tell("Live payment connections need merchant credentials and provider webhook confirmation.")}>Review integration requirements <ArrowUpRight size={15} /></button></div></section>}

    {formOpen && <div className="fixed inset-0 z-50 overflow-y-auto bg-[#081534]/70 p-4 backdrop-blur-sm"><div className="mx-auto my-8 max-w-4xl rounded-3xl bg-[#f6f4ee] p-6 shadow-2xl"><div className="flex items-start justify-between gap-4"><div><p className="text-[10px] font-bold uppercase tracking-[.14em] text-[#a47b06]">New inventory draft</p><h2 className="mt-1 text-3xl font-bold tracking-[-.07em] text-[#0f1f4b]">Stage the next arrival.</h2></div><button onClick={() => setFormOpen(false)} className="rounded-lg px-2 py-1 text-sm font-bold text-[#777269]">Close</button></div><div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{[["Stock number", "stockNumber", "text"], ["VIN", "vin", "text"], ["Make", "make", "text"], ["Model", "model", "text"], ["Trim", "trim", "text"], ["Year", "year", "number"], ["Mileage (km)", "mileageKm", "number"], ["Price (KES)", "priceKsh", "number"], ["FOB (KES)", "fobPriceKsh", "number"], ["Shipping (KES)", "shippingCostKsh", "number"], ["Duty (KES)", "dutyCostKsh", "number"], ["Margin (KES)", "marginKsh", "number"], ["Location", "location", "text"], ["Body type", "bodyType", "text"], ["Fuel", "fuelType", "text"], ["Transmission", "transmission", "text"], ["Exterior color", "exteriorColor", "text"]].map(([label, field, type]) => <label className="grid gap-1.5 text-xs font-bold text-[#0f1f4b]" key={field}>{label}<input type={type} value={vehicleForm[field as keyof typeof vehicleForm] as string | number} onChange={(event) => updateForm(field as keyof typeof vehicleForm, type === "number" ? Number(event.currentTarget.value) : event.currentTarget.value)} className="rounded-xl border border-[#d8d0c2] bg-white px-3 py-2.5 font-normal outline-none focus:border-[#a47b06]" /></label>)}</div><div className="mt-4 grid gap-4 sm:grid-cols-2"><label className="grid gap-1.5 text-xs font-bold text-[#0f1f4b]">Description<textarea value={vehicleForm.description} onChange={(event) => updateForm("description", event.currentTarget.value)} rows={4} className="rounded-xl border border-[#d8d0c2] bg-white p-3 font-normal outline-none focus:border-[#a47b06]" /></label><label className="grid gap-1.5 text-xs font-bold text-[#0f1f4b]">Condition summary<textarea value={vehicleForm.conditionSummary} onChange={(event) => updateForm("conditionSummary", event.currentTarget.value)} rows={4} className="rounded-xl border border-[#d8d0c2] bg-white p-3 font-normal outline-none focus:border-[#a47b06]" /></label></div><label className="mt-4 flex cursor-pointer items-center justify-between rounded-2xl border border-dashed border-[#c8b887] bg-white px-4 py-4"><div className="flex items-center gap-3"><ImagePlus className="text-[#a47b06]" /><div><strong className="block text-sm text-[#0f1f4b]">Add photos or a walkaround video</strong><span className="text-xs text-[#777269]">Images auto-compress to a maximum 1800px before secure upload.</span></div></div><input type="file" multiple accept="image/*,video/*" className="max-w-[170px] text-xs" onChange={(event) => setMediaFiles(Array.from(event.currentTarget.files ?? []))} /></label>{mediaFiles.length > 0 && <p className="mt-2 text-xs text-[#777269]">{mediaFiles.length} file{mediaFiles.length === 1 ? "" : "s"} ready to upload.</p>}<div className="mt-6 flex justify-end gap-3"><button className="rounded-xl border border-[#d8d0c2] px-4 py-3 text-xs font-bold text-[#0f1f4b]" onClick={() => setFormOpen(false)}>Cancel</button><button disabled={createVehicle.isPending || upload.isPending || !vehicleForm.stockNumber || !vehicleForm.make || !vehicleForm.model || !vehicleForm.priceKsh} className="inline-flex items-center gap-2 rounded-xl bg-[#0f1f4b] px-5 py-3 text-xs font-bold text-white disabled:opacity-40" onClick={submitVehicle}>{createVehicle.isPending || upload.isPending ? <Loader2 size={15} className="animate-spin" /> : <Upload size={15} />} Create draft</button></div></div></div>}
  </>}</div>{notice && <div className="fixed bottom-5 right-5 z-[60] flex items-center gap-2 rounded-xl bg-[#0f1f4b] px-4 py-3 text-sm text-white shadow-xl"><CheckCircle2 size={16} className="text-[#efc94c]" />{notice}</div>}</div></DashboardLayout>;
}
